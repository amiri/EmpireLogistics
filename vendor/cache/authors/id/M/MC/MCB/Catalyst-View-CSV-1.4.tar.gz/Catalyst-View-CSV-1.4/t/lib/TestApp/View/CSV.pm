package TestApp::View::CSV;

use base qw ( Catalyst::View::CSV );
use strict;
use warnings;

1;
