package DBICErrorTest::SyntaxError;

use strict;

I'm a syntax error!
