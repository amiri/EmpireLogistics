{
    bar => "baz"
}
