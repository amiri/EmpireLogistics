{   view              => 'View::TT::New',
    'Controller::Foo' => { new => 'key' },
    Component         => { 'Model::Baz' => { 'another' => 'new key' } }
}
