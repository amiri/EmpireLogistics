package TestApp::I18N::fr;

use strict;
use warnings;

use base qw( TestApp::I18N );

our %Lexicon = (
    'Hello' => 'Bonjour'
);

1;
