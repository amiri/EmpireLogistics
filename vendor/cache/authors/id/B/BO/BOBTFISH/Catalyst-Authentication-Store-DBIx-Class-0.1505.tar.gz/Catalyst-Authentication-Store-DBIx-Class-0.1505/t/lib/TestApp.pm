package TestApp;

use strict;
use Catalyst;
use Data::Dumper;

1;
