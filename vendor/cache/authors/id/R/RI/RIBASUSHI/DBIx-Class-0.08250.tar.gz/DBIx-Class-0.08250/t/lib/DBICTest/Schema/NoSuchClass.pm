package DBICTest::Schema::NoSuchClass;

use warnings;
use strict;

## This is purposefully not a real DBIC class
## Used in t/102load_classes.t

1;
