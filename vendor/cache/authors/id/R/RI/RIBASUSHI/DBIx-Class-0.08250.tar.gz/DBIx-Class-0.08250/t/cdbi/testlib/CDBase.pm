package # hide from PAUSE
    CDBase;

use warnings;
use strict;

use base qw(DBIC::Test::SQLite);

1;
