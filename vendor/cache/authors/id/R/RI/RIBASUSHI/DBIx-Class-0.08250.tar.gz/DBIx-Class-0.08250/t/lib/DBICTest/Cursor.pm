package DBICTest::Cursor;

use strict;
use warnings;
use base qw/DBIx::Class::Storage::DBI::Cursor/;

1;
