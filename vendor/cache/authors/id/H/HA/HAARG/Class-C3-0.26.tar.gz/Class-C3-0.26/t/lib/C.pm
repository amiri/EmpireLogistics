package t::lib::C;
use Class::C3;
use base ('t::lib::A', 't::lib::B');
1;
