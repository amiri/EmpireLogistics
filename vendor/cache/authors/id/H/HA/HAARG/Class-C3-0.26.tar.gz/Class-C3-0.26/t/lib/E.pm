package t::lib::E;
use Class::C3;
1;
