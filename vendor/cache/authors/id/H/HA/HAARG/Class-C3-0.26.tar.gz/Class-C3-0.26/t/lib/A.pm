package t::lib::A;
use Class::C3;
1;
