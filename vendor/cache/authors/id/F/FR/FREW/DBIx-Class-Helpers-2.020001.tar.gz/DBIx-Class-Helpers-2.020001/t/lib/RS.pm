package RS;

use base 'ParentRS';

__PACKAGE__->load_components('Helper::ResultSet::Random');

1;
