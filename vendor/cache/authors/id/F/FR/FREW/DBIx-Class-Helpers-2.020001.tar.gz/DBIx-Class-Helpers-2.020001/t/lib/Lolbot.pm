package Lolbot;

use DBIx::Class::Candy;

table 'harrison';

column 'id';
column 'name';

primary_key 'id';

1;
