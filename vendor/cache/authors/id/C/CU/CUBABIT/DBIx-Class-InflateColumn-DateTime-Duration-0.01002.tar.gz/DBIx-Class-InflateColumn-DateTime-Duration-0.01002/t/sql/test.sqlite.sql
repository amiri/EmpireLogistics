create table event (
  id integer primary key not null,
  label varchar(25) not null,
  length varchar(45) not null
);
