package URI::couchdb;
use base 'URI::_db';
our $VERSION = '0.12';

sub default_port { 5984 }

1;
