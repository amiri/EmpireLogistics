package URI::derby;
use base 'URI::_db';
our $VERSION = '0.12';

sub default_port { 1527 }

1;
