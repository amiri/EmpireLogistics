package URI::mongo;
use base 'URI::mongodb';
our $VERSION = '0.12';

1;
