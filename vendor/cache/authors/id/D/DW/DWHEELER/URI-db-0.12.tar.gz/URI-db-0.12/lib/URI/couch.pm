package URI::couch;
use base 'URI::couchdb';
our $VERSION = '0.12';

1;
