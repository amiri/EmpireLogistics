package URI::mssql;
use base 'URI::sqlserver';
our $VERSION = '0.12';

1;
