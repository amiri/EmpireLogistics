package URI::cassandra;
use base 'URI::_db';
our $VERSION = '0.12';

sub default_port { 9160 }

1;
