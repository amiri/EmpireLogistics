package URI::monet;
use base 'URI::monetdb';
our $VERSION = '0.12';

1;
