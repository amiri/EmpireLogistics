package URI::max;
use base 'URI::maxdb';
our $VERSION = '0.12';

1;
