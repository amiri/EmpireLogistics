package URI::maria;
use base 'URI::mysql';
our $VERSION = '0.12';

1;
