package App::Sqitch::Command::good;
use parent 'App::Sqitch::Command';
1;

=head1 NAME

good - Good stuff.

=head1 SYNOPSIS



=head1 DESCRIPTION



=cut

