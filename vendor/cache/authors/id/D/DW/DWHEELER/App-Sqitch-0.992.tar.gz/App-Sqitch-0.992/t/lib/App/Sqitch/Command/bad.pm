package App::Sqitch::Command::bad;

die 'LOL BADZ';
