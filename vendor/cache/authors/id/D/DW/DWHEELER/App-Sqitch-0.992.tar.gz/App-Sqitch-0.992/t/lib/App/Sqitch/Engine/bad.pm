package App::Sqitch::Engine::bad;

die 'LOL BADZ';
