SELECT nick, name FROM __myapp.users WHERE FALSE;
