use v5.10;

say "@ARGV" if @ARGV;
die 'OMGWTF';

