package NotStrict;
BEGIN {
    our $VERSION = '0.1.0';
}
1;
