package Foo;
BEGIN {
	our $VERSION = '1.0';
}
1;
