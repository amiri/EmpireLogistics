package DuplicatePlanRegression;

use Test::Most;

ok 1;

1;
