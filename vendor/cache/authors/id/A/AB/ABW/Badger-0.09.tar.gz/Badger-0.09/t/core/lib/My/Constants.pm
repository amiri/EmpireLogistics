package My::Constants;

use Badger::Class
    words   => 'black none',
    exports => {
        any => 'black none',
    };
    
1;
