package My::Vars2;

use Badger::Class::Vars
    '$FOO' => 'eleven',
    '@BAR' => [11, 21, 31],
    '%BAZ' => {a => 101, b => 202};


1;
