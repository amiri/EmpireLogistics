package My::Bad::Module;

this is intentionally broken
