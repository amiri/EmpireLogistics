package t::Subclass;
use Test::Base -Base;
