
package MyMetaClass::Instance;

use strict;
use warnings;

use parent 'Class::MOP::Instance';

1;
